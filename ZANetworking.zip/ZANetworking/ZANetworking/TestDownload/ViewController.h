//
//  ViewController.h
//  ZANetworking
//
//  Created by CPU12202 on 5/23/19.
//  Copyright © 2019 com.trieund. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DownloadTableViewCell.h"

@interface ViewController : UIViewController <UITableViewDelegate, UITableViewDataSource, DownloadTableViewCellDelegate>


@end

