//
//  ZADownloadPriority.m
//  ZANetworking
//
//  Created by CPU12166 on 5/27/19.
//  Copyright © 2019 com.trieund. All rights reserved.
//

#import <Foundation/Foundation.h>

float ZADownloadPriorityVeryHigh = 1.0;
float ZADownloadPriorityHigh = 0.75;
float ZADownloadPriorityMedium = 0.5;
float ZADownloadPriorityLow = 0.25;
